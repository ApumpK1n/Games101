• [5 points] 提交格式正确，包含所有需要的文件；代码可以在虚拟机下正确 编译运行。 完成

• [20 points] 包围盒求交：正确实现光线与包围盒求交函数。 完成

• [15 points] BVH 查找：正确实现 BVH 加速的光线与场景求交。 完成

• [加分项 20 points] SAH 查找：自学 SAH(Surface Area Heuristic) , 正 确实现 SAH 加速，并且提交结果图片，并在 README.md 中说明 SVH 的实现 方法，并对比 BVH、SVH 的时间开销。(可参考 http://15462.courses.cs .cmu.edu/fall2015/lecture/acceleration/slide_024，也可以查找其他资 料)。  未完成